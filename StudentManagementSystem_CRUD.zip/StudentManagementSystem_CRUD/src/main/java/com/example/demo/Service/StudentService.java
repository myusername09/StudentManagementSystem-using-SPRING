package com.example.demo.Service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.demo.Model.Student;
import com.example.demo.repo.StudentRepository;
/*
 * Service annotation is mainly used with classes that provides the core business functionalities
 */

@Service
public class StudentService {

	@Autowired
	private StudentRepository repo;
	
	//To display all the student details
	public List<Student> listAll(){
		
		return repo.findAll();
	}
	
	//TO save the data in database
	public void save(Student std) {
		
		repo.save(std);
	}
	
	//By getting the ID, used to perform update/edit operation
	public Student get(int id) {
		return repo.findById(id).get();
	}
	
	public void delete(int id) {
		
		repo.deleteById(id);
	}
}
